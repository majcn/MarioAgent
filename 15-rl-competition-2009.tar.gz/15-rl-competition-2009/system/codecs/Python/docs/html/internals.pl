# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/mines-sample/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:env/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sarsa-sample/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/mines-sarsa-sample/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:agent/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structure-types/;
$ref_files{$key} = "$dir".q|PythonCodec.html|; 
$noresave{$key} = "$nosave";

1;

